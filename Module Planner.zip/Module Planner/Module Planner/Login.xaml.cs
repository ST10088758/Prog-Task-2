﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Module_Planner
{

    public partial class Login : Window
    {
        string stdNumber = "";
        string password = "";
        string hash = "";

        public Login()
        {
            InitializeComponent();
        }

        private void registerSubmit_Click(object sender, RoutedEventArgs e)
        {
            string connectionString;
            SqlConnection cnn;            

            connectionString = @"Data Source=ROSS-GAMINGPC;Initial Catalog=STUDY_PLANNER;Integrated Security=True";
            cnn = new SqlConnection(connectionString);
            cnn.Open();

            stdNumber = studentNumberBox.Text;
            password = passwordBox.Text;

            hash = HashPassword(password);

            SqlCommand command;
            SqlDataAdapter dataAdapter = new SqlDataAdapter();
            string sql = "";

            sql =$"INSERT INTO dbo.student VALUES ('{stdNumber}','{hash}')";

            command = new SqlCommand(sql, cnn);

            dataAdapter.InsertCommand = new SqlCommand(sql, cnn);
            dataAdapter.InsertCommand.ExecuteNonQuery();

            command.Dispose();
            cnn.Close();

        }

        private void loginSubmit_Click(object sender, RoutedEventArgs e)
        {
            string connectionString;
            SqlConnection cnn;

            connectionString = @"Data Source=ROSS-GAMINGPC;Initial Catalog=STUDY_PLANNER;Integrated Security=True";
            cnn = new SqlConnection(connectionString);
            cnn.Open();

            stdNumber = studentNumberBox.Text;
            password = passwordBox.Text;

            hash = HashPassword(password);

            SqlCommand command;
            SqlDataReader dataReader;
            string sql, output = "";

            sql = $"SELECT password FROM dbo.student WHERE stdNumber = '{stdNumber}'";

            command = new SqlCommand(sql, cnn);

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                output = output + dataReader.GetString(0);

            }           

            if (output.Equals(hash))
            {
                MessageBox.Show("Logged in");

                MainWindow mainWin = new MainWindow();
                Login loginWin = new Login();

                mainWin.lbl1.Content = studentNumberBox.Text;

                loginWin.Hide();
                mainWin.Show();
            }
            else { MessageBox.Show("Not Logged in");  }

            dataReader.Close();
            command.Dispose();
            cnn.Close();
        }

        public static string HashPassword(string password)
        {
            var sha = SHA256.Create();
            var asByteArray = Encoding.Default.GetBytes(password);

            var hashPassword = sha.ComputeHash(asByteArray);

            return Convert.ToBase64String(hashPassword);

        }

    }
}
