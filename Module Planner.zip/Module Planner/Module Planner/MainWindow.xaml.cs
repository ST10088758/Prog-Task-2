﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using moduleLibrary;

namespace Module_Planner
{
    public partial class MainWindow : Window
    {
        int count = 0; 
        List<Module> modulesList = new List<Module>();
        List<WeeklyHours> weeklyHoursList = new List<WeeklyHours>();
        string stdNumber = "";
        int selfStudy = 0;

        public MainWindow()
        {
            InitializeComponent();
            //FillData();

            //stdNumber = lbl1.Content.ToString();

        }

        private void moduleSubmit_Click(object sender, RoutedEventArgs e)
        {
            string connectionString;
            SqlConnection cnn;

            connectionString = @"Data Source=ROSS-GAMINGPC;Initial Catalog=STUDY_PLANNER;Integrated Security=True";
            cnn = new SqlConnection(connectionString);
            cnn.Open();

            count++;
            
            Module module = new Module();

            string moduleReport = "";
            double selfStudy = 0;

            string code = moduleCode.Text;
            string name = moduleName.Text;
            int credits = Convert.ToInt32(moduleCredits.Text);
            int hours = Convert.ToInt32(classHours.Text);
            int semesterWeekHours = Convert.ToInt32(semesterWeeks.Text);
            string date = startDate.Text;

            module.ModuleCode = code;
            module.ModuleName = name;
            module.Credits = credits;
            module.WeekHours = hours;
            module.SemesterWeeks = semesterWeekHours;
            module.StartDate = date; 

            selfStudy = module.CalcSelfStudyHours();
            module.SelfStudyHours = selfStudy;

            module.AddModule();
            modulesList.Add(module);

            foreach (var x in modulesList)
            {
                moduleReport = moduleReport + ($"Code : {x.ModuleCode} \nName : {x.ModuleName} \nSelf-Study Hours per week : {x.SelfStudyHours}\n");                
            }

            reportBox.Text = (moduleReport);

            moduleList.Items.Clear();

            foreach (var x in modulesList)
            {
                moduleList.Items.Add(x.ModuleCode);
            }

            //submit to database

            SqlCommand command;
            SqlDataAdapter dataAdapter = new SqlDataAdapter();
            string sql = "";

            sql = $"INSERT INTO dbo.module VALUES ('{lbl1.Content.ToString()}','{code}','{name}','{credits}','{hours}', '{semesterWeekHours}')";

            command = new SqlCommand(sql, cnn);

            dataAdapter.InsertCommand = new SqlCommand(sql, cnn);
            dataAdapter.InsertCommand.ExecuteNonQuery();

            command.Dispose();
            

            //submit to hours table

            SqlCommand command2;
            SqlDataAdapter dataAdapter2 = new SqlDataAdapter();
            string sql2 = "";
            stdNumber = lbl1.Content.ToString();

            sql2 = $"INSERT INTO dbo.hours VALUES ('{stdNumber}','{code}',{0},{0})";

            command2 = new SqlCommand(sql, cnn);

            dataAdapter2.InsertCommand = new SqlCommand(sql2, cnn);
            dataAdapter2.InsertCommand.ExecuteNonQuery();

            command2.Dispose();
            cnn.Close();
        }

        public void hoursSubmit_Click(object sender, RoutedEventArgs e)
        {
            string connectionString;
            SqlConnection cnn;

            connectionString = @"Data Source=ROSS-GAMINGPC;Initial Catalog=STUDY_PLANNER;Integrated Security=True";
            cnn = new SqlConnection(connectionString);
            cnn.Open();

            WeeklyHours weeklyHours = new WeeklyHours();

            int hours = Convert.ToInt32(hoursWorked.Text);
            string date = workDate.Text;
            int remaining = 0;
            stdNumber = lbl1.Content.ToString();

            weeklyHours.HoursWorked = hours;
            weeklyHours.Date = date;

            weeklyHours.AddDate();
            weeklyHoursList.Add(weeklyHours);

            string[] list = moduleList.Items.OfType<string>().ToArray();
            int moduleIndex = moduleList.SelectedIndex;
            string moduleQuery = list[moduleIndex];

            var query = from cust
                                in modulesList
                                where cust.ModuleCode == moduleQuery
                                select cust;

            foreach (var x in query)
            {
                x.SelfStudyHours = (x.SelfStudyHours - hours);
                remaining = Convert.ToInt32(x.SelfStudyHours);
            }

            //get self study from database

            int selfStudy = 0;
            SqlCommand command2;
            SqlDataReader dataReader;
            string sql2, output = "";

            sql2 = $"SELECT self_study FROM dbo.hours WHERE (stdNumber = '{stdNumber}') AND (module_code = '{moduleQuery}')";

            command2 = new SqlCommand(sql2, cnn);

            dataReader = command2.ExecuteReader();

            while (dataReader.Read())
            {
                output = output + dataReader.GetInt32(0);
            }

            selfStudy = Convert.ToInt32(output);

            MessageBox.Show(Convert.ToString(remaining));
            MessageBox.Show(Convert.ToString(selfStudy));
            MessageBox.Show(stdNumber);
            MessageBox.Show(moduleQuery);

            command2.Dispose();

            //Update database

           /* int newHours = selfStudy + hours;

            MessageBox.Show(Convert.ToString(newHours));

            SqlCommand commandDelete;
            SqlDataAdapter adapter = new SqlDataAdapter();
            string sqlDel = "";

            sqlDel = "DELETE dbo.hours WHERE stdNumber ='" + stdNumber + "'";

            commandDelete = new SqlCommand(sqlDel, cnn);

            adapter.DeleteCommand = new SqlCommand(sqlDel, cnn);
            adapter.DeleteCommand.ExecuteNonQuery();

            commandDelete.Dispose();

            MessageBox.Show(Convert.ToString(remaining));
            MessageBox.Show(Convert.ToString(newHours));
            MessageBox.Show(stdNumber);
            MessageBox.Show(moduleQuery);

            SqlCommand commandUpdate;
            SqlDataAdapter updateAdapter = new SqlDataAdapter();
            string sqlUp = "";

            sqlUp = $"INSERT INTO dbo.hours VALUES ('{stdNumber}','{moduleQuery}',{newHours},{remaining})";

            commandUpdate = new SqlCommand(sqlUp, cnn);

            updateAdapter.InsertCommand = new SqlCommand(sqlUp, cnn);
            updateAdapter.InsertCommand.ExecuteNonQuery();

            commandUpdate.Dispose();*/
            cnn.Close();

        }

        public void finalSubmit_Click(object sender, RoutedEventArgs e)
        {
            string[] list = moduleList.Items.OfType<string>().ToArray();
            int moduleIndex = moduleList.SelectedIndex;
            string moduleQuery = list[moduleIndex];

            var query = from cust
                                in modulesList
                                where cust.ModuleCode == moduleQuery
                                select cust;

            foreach (var x in query)
            {
                queryBox.Text = $"Module Code : {x.ModuleCode} \n\nHours still needed to work this week : {x.SelfStudyHours} hours";
            }
        }

        private void test_Click(object sender, RoutedEventArgs e)
        {
            stdNumber = lbl1.Content.ToString();

            string connectionString;
            SqlConnection cnn;

            connectionString = @"Data Source=ROSS-GAMINGPC;Initial Catalog=STUDY_PLANNER;Integrated Security=True";
            cnn = new SqlConnection(connectionString);
            cnn.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = $"SELECT * FROM dbo.module WHERE (stdNumber = '{stdNumber}')";

            cmd.Connection = cnn;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("dbo.module");
            da.Fill(dt);

            dataView.ItemsSource = dt.DefaultView;
        }

        /*private void FillData()
        {
            stdNumber = lbl1.Content.ToString();

            string connectionString;
            SqlConnection cnn;

            connectionString = @"Data Source=ROSS-GAMINGPC;Initial Catalog=STUDY_PLANNER;Integrated Security=True";
            cnn = new SqlConnection(connectionString);
            cnn.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = $"SELECT * [dbo.module] WHERE (stdNumber = '{stdNumber}')";

            cmd.Connection = cnn;
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable("dbo.module");
            da.Fill(dt);

            dataView.ItemsSource = dt.DefaultView;

        }*/
    }
}
